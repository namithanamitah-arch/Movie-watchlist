-- Movie Watchlist database schema
-- Run this script in Supabase Dashboard -> SQL Editor.
-- This starter project has one shared watchlist and does not implement user accounts.
-- Do not expose the server-side service role key to browser code.

create extension if not exists pgcrypto;

create table if not exists public.movies (
  id uuid primary key default gen_random_uuid(),
  title varchar(120) not null check (char_length(trim(title)) between 1 and 120),
  director varchar(100),
  release_year integer check (release_year is null or release_year between 1888 and 2100),
  genre varchar(60),
  status varchar(12) not null default 'planned'
    check (status in ('planned', 'watching', 'watched')),
  rating smallint check (rating is null or rating between 1 and 5),
  watched_date date,
  notes varchar(1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists movies_status_idx on public.movies(status);
create index if not exists movies_genre_idx on public.movies(genre);
create index if not exists movies_created_at_idx on public.movies(created_at desc);
create index if not exists movies_title_lower_idx on public.movies(lower(title));

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists movies_set_updated_at on public.movies;
create trigger movies_set_updated_at
before update on public.movies
for each row execute function public.set_updated_at();

-- RLS is enabled as defense-in-depth. The backend uses the Supabase service role
-- key, which bypasses RLS, so the API must never be exposed with that key in a browser.
-- This MVP is a shared, unauthenticated demo list; add authentication and ownership
-- policies before using it for private or multi-user data.
alter table public.movies enable row level security;

-- No anon/authenticated policies are created intentionally. Browser clients cannot
-- access table rows directly; all CRUD runs through the Express backend.
