# Movie Watchlist

A beginner-friendly, full-stack movie watchlist built with HTML, CSS, Vanilla JavaScript, Node.js, Express, and Supabase PostgreSQL. Add movies, track whether you want to watch them, are watching them, or have watched them, and save your personal rating and notes.

## 1. Project overview

### Problem statement
Movie recommendations and titles can be scattered across messages, notes, and streaming apps. Movie Watchlist provides one simple place to keep track of movies you plan to watch and the movies you have already seen.

### Target users
Movie fans and students demonstrating a small full-stack web application. This MVP is a **shared demo watchlist without login or individual accounts**. Anyone who can reach the app can view and change its list. Do not deploy it publicly with private information in its current form.

### Features
- Add, edit, and remove movies.
- Save title, director, release year, genre, status, rating (1–5), date watched, and notes.
- Search title, director, genre, notes, and year.
- Filter by status and genre.
- Sort by recently added, title, release year, or rating.
- Summary cards for total, to-watch, watched, and rated movies.
- Responsive layout, accessible labels, success/error messages, and delete confirmation.
- Server-side validation and PostgreSQL constraints.
- REST API and a database health endpoint.

### Technology stack
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js 20+, Express 5
- Database: Supabase PostgreSQL
- Security utilities: Helmet and express-rate-limit
- Tests: Node.js built-in test runner

## 2. Folder structure

```text
movie-watchlist/
├── frontend/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── backend/
│   ├── routes/
│   │   └── movies.js
│   ├── utils/
│   │   ├── validation.js
│   │   └── validation.test.js
│   ├── server.js
│   ├── supabase.js
│   ├── package.json
│   ├── package-lock.json
│   ├── .env
│   ├── .env.example
│   └── .gitignore
├── database/
│   └── schema.sql
├── .gitignore
└── README.md
```

`backend/.env` in the ZIP contains placeholders only. Replace them locally with your own values. Never commit real credentials.

## 3. Prerequisites

Install these on Windows:
- [Visual Studio Code](https://code.visualstudio.com/)
- [Node.js LTS](https://nodejs.org/) (Node 20 or newer)
- [Git](https://git-scm.com/downloads)
- A free [Supabase](https://supabase.com/) account

## 4. Setup instructions (Windows)

### Step 1 — Extract and open the project
1. Extract `movie-watchlist.zip`.
2. Open VS Code.
3. Choose **File → Open Folder** and select the extracted `movie-watchlist` folder.
4. Open **Terminal → New Terminal**. Commands below assume the terminal is at the project root unless noted.

### Step 2 — Check Node.js and Git
Run:
```powershell
node --version
npm --version
git --version
```
Node should report version 20 or newer. If a command is not recognized, install that tool and restart VS Code.

### Step 3 — Create a Supabase project
1. Sign in at Supabase and create a new project.
2. Choose a project name and a strong database password. Save the password privately.
3. Wait until the project is ready.
4. Open **SQL Editor → New query**.
5. Open `database/schema.sql` in VS Code, copy all its SQL, paste it into the Supabase SQL Editor, and click **Run**.
6. Open **Table Editor** and verify that the `movies` table exists.

The schema creates the `movies` table, validation constraints, indexes, an `updated_at` trigger, and enables Row Level Security (RLS). No direct browser policies are created because the browser never connects to Supabase directly.

### Step 4 — Configure backend environment variables
1. In VS Code, open `backend/.env`.
2. In Supabase, open **Project Settings → API** (the label/location can vary slightly by dashboard version).
3. Copy the project URL into `SUPABASE_URL`.
4. Copy the **service_role/secret server key** into `SUPABASE_SERVICE_ROLE_KEY`. Use the server-only secret key shown by your project; do not use a publishable key for this backend implementation.
5. Keep `PORT=3000` and `NODE_ENV=development` for local use.

Example shape (not real credentials):
```dotenv
PORT=3000
NODE_ENV=development
SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVER_SIDE_SECRET_KEY
```
The example values do not connect to a database. Do not share the real `.env` file, put its contents in screenshots, or commit it to GitHub. The backend uses this privileged key and therefore performs its own request validation. It is never sent to the browser.

### Step 5 — Install dependencies
From the **project root**, run:
```powershell
cd backend
npm install
```
npm downloads Express, the Supabase client, dotenv, Helmet, and express-rate-limit into `backend/node_modules/`. Wait for the command to finish without errors.

### Step 6 — Start the application
Still inside `backend/`, run:
```powershell
npm run dev
```
Expected terminal output:
```text
Movie Watchlist running at http://localhost:3000
```
Open [http://localhost:3000](http://localhost:3000) in your browser. Keep the terminal running while using the app. Press `Ctrl+C` to stop the server. For normal startup without file watching, use `npm start`.

### Step 7 — Verify the server and database
Open these URLs in the browser:
- `http://localhost:3000/api/health` — should return `{"status":"ok","application":"movie-watchlist"}`.
- `http://localhost:3000/api/health/database` — should return `{"status":"ok","database":"connected"}` after the SQL schema and credentials are correct.

Add a movie in the interface, refresh the page, and verify it remains in the list. This persistence check confirms the API is reading from Supabase.

### Step 8 — Run tests
Open another terminal, navigate to the backend folder, and run:
```powershell
cd backend
npm test
```
The validation tests use Node's built-in test runner and do not need a live Supabase connection.

## 5. How the application works

1. The browser renders `frontend/index.html`, styled by `styles.css`.
2. `frontend/app.js` uses `fetch()` to call the Express API.
3. `backend/server.js` configures security middleware, static file serving, health endpoints, and routes.
4. `backend/routes/movies.js` validates requests and runs Supabase queries.
5. Supabase PostgreSQL stores movie records permanently.

The service-role key bypasses RLS. For this reason, this demo is suitable only for local/classroom use or a controlled trusted environment. Before a public deployment, add authentication, user ownership, authorization, and appropriate RLS policies; do not simply expose the API publicly as-is.

## 6. Database design

`movies` columns:
- `id`: UUID primary key
- `title`: required movie title
- `director`, `release_year`, `genre`: optional details
- `status`: `planned`, `watching`, or `watched`
- `rating`: optional integer from 1 to 5
- `watched_date`: optional date
- `notes`: optional text up to 1000 characters
- `created_at`, `updated_at`: timestamps

The MVP intentionally uses one shared table and has no users table because authentication is not included. A future version should add a user identity and a `user_id` foreign key, and scope every query to the authenticated owner.

## 7. REST API reference

All routes are served by the local Express server. JSON request bodies are used for create/update operations.

| Method | Path | Purpose | Request body / result |
|---|---|---|---|
| GET | `/api/health` | Server health check | Returns status JSON |
| GET | `/api/health/database` | Test database configuration and table access | Returns connected status or 503 |
| GET | `/api/movies` | List all movies, newest first | Returns `{ "movies": [...] }` |
| POST | `/api/movies` | Create a movie | Send movie fields; returns 201 and `{ "movie": {...} }` |
| PUT | `/api/movies/:id` | Update a movie | Send all movie fields; returns updated movie or 404 |
| DELETE | `/api/movies/:id` | Delete a movie | Returns success message or 404 |

No route has user authentication in this classroom MVP. API input is validated server-side. Invalid data returns HTTP 400; unexpected server/database failures return a generic HTTP 500 response; a missing movie returns 404. API requests are rate-limited.

Example `POST /api/movies` body:
```json
{
  "title": "Arrival",
  "director": "Denis Villeneuve",
  "release_year": 2016,
  "genre": "Sci-Fi",
  "status": "planned",
  "rating": null,
  "watched_date": null,
  "notes": "Recommended by a friend"
}
```

## 8. Manual testing checklist

| Test | Steps | Expected result |
|---|---|---|
| Load app | Open localhost:3000 | Watchlist interface appears |
| Health check | Open `/api/health` | Status is `ok` |
| Database check | Open `/api/health/database` | Connected status after setup |
| Add movie | Enter a title and save | Movie appears in the list |
| Persistence | Refresh the browser | Saved movie remains |
| Edit movie | Change title or status and save | Card reflects the update |
| Delete movie | Remove a movie and confirm | Movie disappears |
| Required title | Submit a blank title | Friendly validation message |
| Invalid rating/year | Send invalid values to API | HTTP 400 response |
| Search | Search for a title/director | Only matching movies appear |
| Filter | Choose a status or genre | Matching movies appear |
| Sort | Change the sort dropdown | Cards reorder |
| Empty state | Clear or filter to no results | Helpful empty message appears |
| Responsive view | Narrow the browser window | Layout adapts to mobile width |
| Database unavailable | Temporarily use incorrect credentials | App displays a database/server error, not secret values |

## 9. Troubleshooting

- **`npm` or `node` not recognized:** Install Node.js LTS, close and reopen VS Code, then check the versions.
- **Port 3000 already in use:** Change `PORT=3001` in `backend/.env`, restart the server, and open `http://localhost:3001`.
- **Database health returns 503:** Check the Supabase URL, server-side key, and that `database/schema.sql` ran successfully.
- **Table does not exist:** Re-run `database/schema.sql` in the correct Supabase project.
- **Invalid API key / permission error:** Verify you copied the correct server-side secret key from the same Supabase project as the URL. Never put it in frontend files.
- **Page loads but styles are missing:** Confirm `frontend/styles.css` exists and reload the page.
- **Changes do not appear:** Check the terminal for errors, refresh the browser, and confirm the correct project folder is running.

## 10. Upload to GitHub

1. Create a new repository on [GitHub](https://github.com/new). Do not add secrets or database exports.
2. From the project root in VS Code terminal, run:
```powershell
git init
git status
git add .
git status
git commit -m "Build Movie Watchlist project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
3. Replace `YOUR_GITHUB_REPOSITORY_URL` with the repository URL shown by GitHub.
4. Visit the repository page and verify that `frontend/`, `backend/`, `database/`, and `README.md` are present.

Before committing, confirm that `backend/.env` is ignored and contains only local values. The root `.gitignore` excludes it. If a real key is ever committed, rotate/revoke it immediately; adding a file to `.gitignore` does not remove secrets from Git history.

## 11. Limitations and future improvements

Current limitations:
- No sign-in or individual user lists; all visitors to the API share one list.
- No movie poster service or external movie database is used.
- The app is intended as a classroom/local MVP, not a public multi-user service.

Possible improvements:
- Add Supabase Auth and owner-specific watchlists.
- Add a movie details page and poster uploads.
- Add pagination for large collections.
- Add export/import and richer viewing statistics.
- Deploy the frontend and backend securely after adding authentication and access controls.

## 12. Learning outcomes

By exploring this project, students can practice HTML forms, CSS responsive layouts, DOM manipulation, `fetch()`, REST endpoints, server-side validation, environment variables, SQL constraints, database queries, and Git/GitHub basics.
